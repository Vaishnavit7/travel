const itinerary = [];
const itineraryList = document.getElementById("itineraryList");
const tripForm = document.getElementById("tripForm");
let map, markerGroup;

// Initialize Leaflet map
function initMap() {
  map = L.map("map").setView([20, 0], 2);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(map);
  markerGroup = L.layerGroup().addTo(map);
}

tripForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const city = document.getElementById("city").value;
  const date = document.getElementById("date").value;
  const coords = await getCoordinates(city);

  if (!coords) {
    alert("Could not find location.");
    return;
  }

  const destination = { city, date, coords };
  itinerary.push(destination);
  renderItinerary();
  updateMap();
  tripForm.reset();
});

function renderItinerary() {
  itineraryList.innerHTML = "";
  itinerary.forEach((dest) => {
    const item = document.createElement("li");
    item.textContent = `${dest.date} - ${dest.city}`;
    itineraryList.appendChild(item);
  });
}

function updateMap() {
  markerGroup.clearLayers();
  itinerary.forEach((dest) => {
    const marker = L.marker(dest.coords).addTo(markerGroup);
    marker.bindPopup(`${dest.city}<br>${dest.date}`).openPopup();
  });

  if (itinerary.length > 0) {
    const last = itinerary[itinerary.length - 1];
    map.setView(last.coords, 6);
  }
}

async function getCoordinates(place) {
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
        place
      )}`
    );
    const data = await response.json();
    if (data.length === 0) return null;
    return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
  } catch (err) {
    console.error(err);
    return null;
  }
}

initMap();
